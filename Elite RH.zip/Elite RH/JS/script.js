// Função para carregar componentes HTML dinâmicos
async function carregarComponente(id, arquivo) {
    try {
        const elemento = document.getElementById(id);
        if (!elemento) {
            console.error(`Elemento com ID "${id}" não encontrado.`);
            return;
        }

        // Exibir indicador de carregamento
        elemento.innerHTML = '<div class="carregando">Carregando...</div>';

        const response = await fetch(`components/${arquivo}`);
        if (!response.ok) {
            throw new Error(`Erro ao carregar ${arquivo}: ${response.status} ${response.statusText}`);
        }
        const data = await response.text();
        elemento.innerHTML = data;

        // Remover indicador de carregamento
        elemento.querySelector('.carregando')?.remove();

    } catch (error) {
        console.error(`Erro ao carregar ${arquivo}:`, error);
        const elemento = document.getElementById(id);
        if (elemento) {
            elemento.innerHTML = '<div class="erro-carregamento">Erro ao carregar o conteúdo.</div>';
        }
    }
}

// Carregar navbar e footer quando a página for carregada
document.addEventListener('DOMContentLoaded', function() {
    // Verifique se o elemento com o ID existe antes de chamar carregarComponente
    if (document.getElementById("navbar")) {
        carregarComponente("navbar", "navbar.html");
    }
    if (document.getElementById("footer")) {
        carregarComponente("footer", "footer.html");
    }
});